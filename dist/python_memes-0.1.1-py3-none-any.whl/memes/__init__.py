from .memes import MemeFetcher

__all__ = ["MemeFetcher"]
